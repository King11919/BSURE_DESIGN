const express = require('express');
const cors = require('cors');
const multer = require('multer');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5001;

// ─── Config ───────────────────────────────────────────────────────────────────
const JWT_SECRET = process.env.JWT_SECRET || 'blocksurety-admin-secret-CHANGE-THIS-NOW';
let ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123'; // overwritten by change-password

const DATA_FILE   = path.join(__dirname, 'data', 'assets.json');
const CONFIG_FILE = path.join(__dirname, 'data', 'config.json');
const UPLOADS_DIR = path.join(__dirname, 'uploads');

// Ensure directories exist (recursive: true so nested paths work)
fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
fs.mkdirSync(UPLOADS_DIR, { recursive: true });

// ─── Rate Limiter (simple in-memory, no extra deps) ──────────────────────────
const loginAttempts = new Map();
function rateLimitLogin(req, res, next) {
  const ip = req.ip || req.connection.remoteAddress;
  const now = Date.now();
  const window = 15 * 60 * 1000; // 15 minutes
  const maxAttempts = 10;

  const record = loginAttempts.get(ip) || { count: 0, start: now };
  if (now - record.start > window) {
    // Reset window
    record.count = 0;
    record.start = now;
  }
  record.count++;
  loginAttempts.set(ip, record);

  if (record.count > maxAttempts) {
    const retryAfter = Math.ceil((window - (now - record.start)) / 1000);
    return res.status(429).json({
      error: `Too many login attempts. Try again in ${retryAfter} seconds.`,
    });
  }
  next();
}

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(cors({
  origin: [
    'https://admin.blocksurety.io',
    'https://blocksurety.io',
    'https://www.blocksurety.io',
    'http://localhost:5173',
    'http://localhost:3000',
  ],
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));
app.use(express.json({ limit: '2mb' }));
app.use('/uploads', express.static(UPLOADS_DIR));

// ─── Image Upload ─────────────────────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}-${Math.random().toString(36).slice(2)}${ext}`);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (allowed.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`File type not allowed: ${file.mimetype}. Use JPG, PNG, WebP, or GIF.`));
    }
  },
});

// ─── Auth Middleware ──────────────────────────────────────────────────────────
function requireAuth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token provided' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

// ─── Data Helpers ─────────────────────────────────────────────────────────────
function loadAssets() {
  try {
    if (!fs.existsSync(DATA_FILE)) return [];
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('Error loading assets.json:', err.message);
    return [];
  }
}

function saveAssets(assets) {
  try {
    if (!Array.isArray(assets)) throw new Error('Assets must be an array');
    fs.writeFileSync(DATA_FILE, JSON.stringify(assets, null, 2), 'utf8');
    return true;
  } catch (err) {
    console.error('Error saving assets.json:', err.message);
    throw new Error('Failed to save assets to disk');
  }
}

function loadConfig() {
  try {
    if (!fs.existsSync(CONFIG_FILE)) return {};
    return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
  } catch {
    return {};
  }
}

function saveConfig(cfg) {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2), 'utf8');
}

// Sanitize asset ID — only allow safe slugs
function sanitizeId(id) {
  return String(id)
    .toLowerCase()
    .replace(/[^a-z0-9-]/g, '-')
    .replace(/--+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 100);
}

// ─── Routes ───────────────────────────────────────────────────────────────────

// ── Auth ──────────────────────────────────────────────────────────────────────

// Login
app.post('/api/auth/login', rateLimitLogin, (req, res) => {
  try {
    const { password } = req.body;
    if (!password) return res.status(400).json({ error: 'Password required' });

    // Check saved password override first, then env/default
    const cfg = loadConfig();
    const currentPassword = cfg.adminPassword || ADMIN_PASSWORD;

    if (password !== currentPassword) {
      return res.status(401).json({ error: 'Invalid password' });
    }

    // Clear rate limit on successful login
    const ip = req.ip || req.connection.remoteAddress;
    loginAttempts.delete(ip);

    const token = jwt.sign({ role: 'admin' }, JWT_SECRET, { expiresIn: '24h' });
    res.json({ token });
  } catch (err) {
    res.status(500).json({ error: 'Login error' });
  }
});

// Verify token (used on page refresh to check if still logged in)
app.get('/api/auth/verify', requireAuth, (req, res) => {
  res.json({ valid: true, role: req.user.role });
});

// ✅ FIX: Change admin password (WAS MISSING — settings page calls this)
app.post('/api/auth/change-password', requireAuth, (req, res) => {
  try {
    const { newPassword } = req.body;
    if (!newPassword) return res.status(400).json({ error: 'newPassword is required' });
    if (newPassword.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });

    const cfg = loadConfig();
    cfg.adminPassword = newPassword;
    saveConfig(cfg);

    // Also update in-memory
    ADMIN_PASSWORD = newPassword;

    res.json({ success: true, message: 'Password changed successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to change password' });
  }
});

// ── Assets (protected) ───────────────────────────────────────────────────────

// Get all assets (admin — full data)
app.get('/api/assets', requireAuth, (req, res) => {
  try {
    res.json(loadAssets());
  } catch (err) {
    res.status(500).json({ error: 'Failed to load assets' });
  }
});

// ✅ NEW: Public endpoint — main site (blocksurety.io) can use this without a token
// Returns full assets list (no private/admin-only fields exposed)
app.get('/api/assets-public', (req, res) => {
  try {
    const assets = loadAssets();
    res.json(assets);
  } catch (err) {
    res.status(500).json({ error: 'Failed to load assets' });
  }
});

// Create asset
app.post('/api/assets', requireAuth, (req, res) => {
  try {
    const { name } = req.body;
    if (!name || typeof name !== 'string' || !name.trim()) {
      return res.status(400).json({ error: 'Asset name is required' });
    }

    const assets = loadAssets();

    // ✅ FIX: sanitize ID to prevent path traversal / injection
    const rawId = req.body.id || name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const id = sanitizeId(rawId);

    if (!id) return res.status(400).json({ error: 'Could not generate a valid asset ID' });
    if (assets.find(a => a.id === id)) {
      return res.status(400).json({ error: `Asset ID "${id}" already exists` });
    }

    const asset = {
      ...req.body,
      id,
      name: name.trim(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    assets.push(asset);
    saveAssets(assets);
    res.status(201).json(asset);
  } catch (err) {
    res.status(500).json({ error: err.message || 'Failed to create asset' });
  }
});

// Update asset
app.put('/api/assets/:id', requireAuth, (req, res) => {
  try {
    const id = sanitizeId(req.params.id);
    const assets = loadAssets();
    const idx = assets.findIndex(a => a.id === id);
    if (idx === -1) return res.status(404).json({ error: `Asset "${id}" not found` });

    assets[idx] = {
      ...assets[idx],
      ...req.body,
      id,                              // prevent ID change via body
      createdAt: assets[idx].createdAt, // preserve original creation date
      updatedAt: new Date().toISOString(),
    };
    saveAssets(assets);
    res.json(assets[idx]);
  } catch (err) {
    res.status(500).json({ error: err.message || 'Failed to update asset' });
  }
});

// Delete asset
app.delete('/api/assets/:id', requireAuth, (req, res) => {
  try {
    const id = sanitizeId(req.params.id);
    const assets = loadAssets();
    const filtered = assets.filter(a => a.id !== id);
    if (filtered.length === assets.length) {
      return res.status(404).json({ error: `Asset "${id}" not found` });
    }
    saveAssets(filtered);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message || 'Failed to delete asset' });
  }
});

// ── Image Upload ──────────────────────────────────────────────────────────────

app.post('/api/upload', requireAuth, (req, res, next) => {
  upload.single('image')(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({ error: 'File too large. Maximum size is 10MB.' });
      }
      return res.status(400).json({ error: err.message });
    } else if (err) {
      // ✅ FIX: fileFilter errors now returned properly
      return res.status(400).json({ error: err.message });
    }

    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

    res.json({
      url: `https://admin.blocksurety.io/uploads/${req.file.filename}`,
      filename: req.file.filename,
      size: req.file.size,
      mimetype: req.file.mimetype,
    });
  });
});

// ── Stats ─────────────────────────────────────────────────────────────────────

app.get('/api/stats', requireAuth, (req, res) => {
  try {
    const assets = loadAssets();
    const totalValue = assets.reduce((s, a) => s + (Number(a.totalValue) || 0), 0);
    const totalTokens = assets.reduce((s, a) => s + (Number(a.totalTokens) || 0), 0);
    const featured = assets.filter(a => a.featured).length;
    const withApy = assets.filter(a => a.apy);
    const avgApy = withApy.length
      ? (withApy.reduce((s, a) => s + Number(a.apy), 0) / withApy.length).toFixed(2)
      : null;
    const totalSold = assets.reduce((s, a) => s + (Number(a.sold) || 0), 0);
    const avgSold = assets.length ? (totalSold / assets.length).toFixed(1) : 0;

    res.json({
      totalAssets: assets.length,
      totalValue,
      totalTokens,
      featured,
      avgApy,
      avgSold,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to compute stats' });
  }
});

// ── Seed ──────────────────────────────────────────────────────────────────────

// ✅ FIX: Validate that assets is a real array before saving
app.post('/api/seed', requireAuth, (req, res) => {
  try {
    const { assets } = req.body;
    if (!Array.isArray(assets)) {
      return res.status(400).json({ error: 'Request body must contain an "assets" array' });
    }
    if (assets.length === 0) {
      return res.status(400).json({ error: 'Assets array is empty' });
    }

    // Sanitize IDs in seeded data
    const sanitized = assets.map(a => ({
      ...a,
      id: sanitizeId(a.id || a.name || 'asset'),
      createdAt: a.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }));

    saveAssets(sanitized);
    res.json({ seeded: sanitized.length });
  } catch (err) {
    res.status(500).json({ error: err.message || 'Seed failed' });
  }
});

// ─── Global Error Handler ─────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

// ─── 404 handler ─────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: `Route not found: ${req.method} ${req.path}` });
});

// ─── Start ────────────────────────────────────────────────────────────────────
app.listen(PORT, '127.0.0.1', () => {
  console.log(`✅ BlockSurety Admin API running on http://127.0.0.1:${PORT}`);
  console.log(`   Data file : ${DATA_FILE}`);
  console.log(`   Uploads   : ${UPLOADS_DIR}`);
});