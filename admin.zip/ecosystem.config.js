module.exports = {
  apps: [
    {
      name: 'blocksurety-admin-api',
      script: 'server.js',
      cwd: '/var/www/blocksurety-admin',
      instances: 1,
      autorestart: true,
      watch: false,
      max_restarts: 10,
      restart_delay: 3000,
      env: {
        NODE_ENV: 'production',
        PORT: 5001,
        JWT_SECRET: 'blocksurety-super-secret-jwt-key-2024',
        ADMIN_PASSWORD: 'Admin@123',
      },
      error_file: '/var/log/blocksurety-admin/err.log',
      out_file: '/var/log/blocksurety-admin/out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
    },
  ],
};
