#!/bin/bash
# ============================================================
# BlockSurety Admin Panel — One-Shot Deploy Script
# Run on VPS as root: bash deploy.sh
# ============================================================

set -e  # Exit on any error

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║   BlockSurety Admin Panel — Deployment Script        ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

ADMIN_DIR="/var/www/blocksurety-admin"
LOG_DIR="/var/log/blocksurety-admin"

# ── 1. Create directories ────────────────────────────────────
echo "▸ [1/9] Creating directories..."
mkdir -p "$ADMIN_DIR/data"
mkdir -p "$ADMIN_DIR/uploads"
mkdir -p "$LOG_DIR"

# ── 2. Copy files ────────────────────────────────────────────
echo "▸ [2/9] Copying project files..."
# Assumes you've already uploaded the files to $ADMIN_DIR
# (index.html, server.js, package.json, ecosystem.config.js, .env)
if [ ! -f "$ADMIN_DIR/server.js" ]; then
    echo "  ✗ ERROR: server.js not found in $ADMIN_DIR"
    echo "  Upload these files first:"
    echo "    - index.html"
    echo "    - server.js"
    echo "    - package.json"
    echo "    - ecosystem.config.js"
    echo "    - .env"
    exit 1
fi

if [ ! -f "$ADMIN_DIR/.env" ]; then
    echo "  ⚠ WARNING: .env not found — creating from template..."
    JWT=$(openssl rand -hex 32)
    cat > "$ADMIN_DIR/.env" <<EOF
JWT_SECRET=$JWT
ADMIN_PASSWORD=admin123
PORT=5001
EOF
    echo "  ✓ .env created with random JWT secret"
    echo "  ⚠ IMPORTANT: Change ADMIN_PASSWORD in $ADMIN_DIR/.env !"
fi

# ── 3. Install Node.js dependencies ─────────────────────────
echo "▸ [3/9] Installing Node.js dependencies..."
cd "$ADMIN_DIR"
npm install --production

# ── 4. Install PM2 globally ─────────────────────────────────
echo "▸ [4/9] Installing PM2..."
if ! command -v pm2 &> /dev/null; then
    npm install -g pm2
    echo "  ✓ PM2 installed"
else
    echo "  ✓ PM2 already installed"
fi

# ── 5. Start/restart with PM2 ───────────────────────────────
echo "▸ [5/9] Starting API with PM2..."
cd "$ADMIN_DIR"

# Load .env vars into PM2
set -a
source "$ADMIN_DIR/.env" 2>/dev/null || true
set +a

# Stop existing instance if running
pm2 delete blocksurety-admin-api 2>/dev/null || true

# Start fresh
pm2 start ecosystem.config.js --env production
pm2 save

# Setup PM2 to auto-start on server reboot
pm2 startup systemd -u root --hp /root 2>/dev/null || true
pm2 save

echo "  ✓ API running on port ${PORT:-5001}"

# ── 6. Enable Apache modules ────────────────────────────────
echo "▸ [6/9] Enabling Apache modules..."
a2enmod proxy proxy_http rewrite ssl headers 2>/dev/null || true
echo "  ✓ Modules enabled"

# ── 7. Setup Apache virtual host ────────────────────────────
echo "▸ [7/9] Setting up Apache virtual host..."
VHOST_FILE="/etc/apache2/sites-available/admin.blocksurety.io.conf"

if [ -f "$ADMIN_DIR/admin.blocksurety.io.conf" ]; then
    cp "$ADMIN_DIR/admin.blocksurety.io.conf" "$VHOST_FILE"
    echo "  ✓ Virtual host copied"
else
    echo "  ⚠ admin.blocksurety.io.conf not found in $ADMIN_DIR — skipping"
fi

a2ensite admin.blocksurety.io 2>/dev/null || true

# Test Apache config before reloading
echo "  Testing Apache config..."
if apache2ctl configtest 2>&1 | grep -q "Syntax OK"; then
    systemctl reload apache2
    echo "  ✓ Apache reloaded"
else
    echo "  ✗ Apache config error! Run: apache2ctl configtest"
    echo "  ⚠ You may need to get SSL cert first (step 8) before Apache accepts the vhost"
fi

# ── 8. SSL Certificate ──────────────────────────────────────
echo "▸ [8/9] SSL Certificate..."
echo ""
echo "  ┌─────────────────────────────────────────────────────┐"
echo "  │  Run this manually AFTER DNS is pointed:            │"
echo "  │                                                     │"
echo "  │  certbot --apache -d admin.blocksurety.io           │"
echo "  │                                                     │"
echo "  │  If DNS is already pointed, run it now!             │"
echo "  └─────────────────────────────────────────────────────┘"
echo ""

# ── 9. Set permissions ──────────────────────────────────────
echo "▸ [9/9] Setting permissions..."
chown -R www-data:www-data "$ADMIN_DIR"
chmod -R 755 "$ADMIN_DIR"
chmod 600 "$ADMIN_DIR/.env"  # Only root can read secrets
echo "  ✓ Permissions set"

# ── Done ─────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║   ✅ Deployment Complete!                            ║"
echo "╠══════════════════════════════════════════════════════╣"
echo "║                                                      ║"
echo "║  Admin UI:  https://admin.blocksurety.io             ║"
echo "║  API:       https://admin.blocksurety.io/api/        ║"
echo "║  Uploads:   $ADMIN_DIR/uploads/        ║"
echo "║  Data:      $ADMIN_DIR/data/           ║"
echo "║  Logs:      $LOG_DIR/                  ║"
echo "║                                                      ║"
echo "║  PM2 commands:                                       ║"
echo "║    pm2 status                                        ║"
echo "║    pm2 logs blocksurety-admin-api                    ║"
echo "║    pm2 restart blocksurety-admin-api                 ║"
echo "║                                                      ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# Quick health check
echo "▸ Health check..."
sleep 2
if curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:${PORT:-5001}/api/stats 2>/dev/null | grep -q "401"; then
    echo "  ✓ API is responding (401 = auth required, that's correct!)"
else
    echo "  ⚠ API may not be responding yet. Check: pm2 logs blocksurety-admin-api"
fi

echo ""
echo "Done! 🎉"
